module.exports = {
  plugins: {
    'autoprefixer': {},
    'cssnano': {
      zindex: false
    }
  }
}