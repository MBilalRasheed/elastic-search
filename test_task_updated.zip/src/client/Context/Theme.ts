import { createContext } from 'react';

export const ContextTheme = {
};

export const ThemeContext = createContext(ContextTheme);
