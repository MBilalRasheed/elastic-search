import * as React from 'react';

export default () => (
  <h1 className="center">Not Found. =(</h1>
);
