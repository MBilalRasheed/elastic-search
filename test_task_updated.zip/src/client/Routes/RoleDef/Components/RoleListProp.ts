import { IRoleDef } from '../../../Types/Domain/Role';

export interface RoleListProp {
  roleDefs: IRoleDef[];
  theme?: any;
  actions?: any
}
