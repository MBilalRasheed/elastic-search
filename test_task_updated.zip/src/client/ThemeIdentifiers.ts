export const APP = 'ThApp';
export const CONTENT = 'ThContent';
export const CONTENTINS = 'ThContentIns';
export const ESPINNER = 'ThESpinner';
export const GROUP = 'ThGroup';
export const HEADER = 'ThHeader';
export const MAINLAYOUT = 'ThMainLayout';
export const MESSAGES = 'ThMessages';
export const MESSAGECHANNEL = 'ThMessageChannel';
export const MESSAGESOURCEDEF = "ThMessageSourceDef";
export const ROLE = 'ThRole';
export const USER = 'ThUser';
export const VALUEDEF = 'ThValueDef';

