export const baseUrl = '/api/v1';
export const placeHolderForEsLine = 'Remove when more things to export';
