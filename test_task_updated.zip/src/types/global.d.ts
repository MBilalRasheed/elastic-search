declare var EMG_API_URL: boolean;
